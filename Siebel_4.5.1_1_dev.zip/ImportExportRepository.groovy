import com.serena.air.StepFailedException
import com.serena.air.StepPropertiesHelper
import com.urbancode.air.AirPluginTool;
import com.serena.air.siebel.SiebelCLIHelper

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = new StepPropertiesHelper(apTool.getStepProperties(), true)

String homeDir        = props.notNull('homeDir')
String user           = props.notNull('user')
String pass           = props.notNull('pass')

String action         = props.notNull('Action')
String odbcDataSource = props.notNull('ODBCDataSource')
String dbTableOwner   = props.notNull('DBTableOwner')
String repoFilePath       = props.notNull('repoFilePath')
String repository       = props.optional('repository')
String additionalParams = props.optional('AdditionalParams')

try{
    SiebelCLIHelper cliHelper = new SiebelCLIHelper(homeDir, user, pass, apTool.isWindows)
    cliHelper.importExportRepo(action, odbcDataSource, dbTableOwner, repoFilePath, repository, additionalParams)
} catch (StepFailedException e) {
    println ''
    println "ERROR: ${e.getMessage()}"
    System.exit(1)
}