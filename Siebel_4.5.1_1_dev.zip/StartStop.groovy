import com.serena.air.StepFailedException
import com.serena.air.StepPropertiesHelper
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;
import com.urbancode.air.ExitCodeException;
import java.text.SimpleDateFormat;

println('Executing step: start or stop servers')

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = new StepPropertiesHelper(apTool.getStepProperties(), true)

String dateString = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())

String siebelServer        = props.optional('SiebelServer') ///THIS NEEDS TO CHANGE????
String SiebEnterprise      = props.optional('SiebelEnt')

String ServerHomeDirectory = props.notNull('SiebelHomeDirectory')
String actionString        = props.notNull('Action')
String serverType          = props.notNull('ServerType')
String gwServer            = props.optional('GatewayServer')
String gwPort              = props.optional('GatewayPort')
String sbUser              = props.optional('SiebelUser')
String sbPass              = props.optional('SiebelPass')

boolean isUnix = !System.getProperty("os.name").startsWith("Win")
if (isUnix) {
    println(" We are running in a Unix/Linux environment")
} else {
    println(" We are running in a Windows environment")
}

println System.getenv('HOME').toString()
def workDir = new File("ucd_sieb_$dateString");
def scriptFile = new File(workDir.path + workDir.separator + "scriptFile");
def checkFile = new File(workDir.path + workDir.separator + "checkFile");

boolean serverIsNotStarted = false;

try {
        //	alias startapa='/usr/IBM/HTTPServer/bin/startapa'
        //	alias startgate='. $HOME/.profile;. $GATEWAY_HOME/siebenv.sh ;$GATEWAY_HOME/bin/start_ns'
        //	alias startsiebel='. $HOME/.profile;. $SIEBEL_HOME/siebenv.sh ;$SIEBEL_HOME/bin/start_server all'
        //	alias stopapa='/usr/IBM/HTTPServer/bin/stopapa'
        //	alias stopgate='. $HOME/.profile;. $GATEWAY_HOME/siebenv.sh ; $GATEWAY_HOME/bin/stop_ns'
        //	alias stopsiebel='. $HOME/.profile; . $SIEBEL_HOME/siebenv.sh ; $SIEBEL_HOME/bin/stop_server all'

    println(" Making directory [$workDir.path]");
    workDir.mkdir();
//    writer = new PrintWriter(scriptFile);

    scriptFile.withWriter { writer ->
        def envString
        def commandString
        if (isUnix) {
            println(" Server Type: [$serverType] in dir:[$ServerHomeDirectory]");
            switch (serverType) {
                case 'Siebel':
                    envString = ". \$HOME/.profile; SIEBEL_HOME=$ServerHomeDirectory; export SIEBEL_HOME; . \$SIEBEL_HOME/siebenv.sh;";
                    if (actionString.toString().equalsIgnoreCase("start")) {
                        println(" Cooking Siebel Server start script");
                        commandString = "\$SIEBEL_HOME/bin/start_server all";
                        serverIsNotStarted = true;
                    } else {
                        println(" Cooking Siebel Server stop script");
                        commandString = "\$SIEBEL_HOME/bin/stop_server all";
                    }
                    break;
                case 'Gateway':
                    envString = ". \$HOME/.profile; GATEWAY_HOME=$ServerHomeDirectory; export GATEWAY_HOME; . \$GATEWAY_HOME/siebenv.sh;";
                    if (actionString.toString().equalsIgnoreCase("start")) {
                        println(" Cooking Gateway Server start script");
                        commandString = "\$GATEWAY_HOME/bin/start_ns";
                    } else {
                        println(" Cooking Gateway Server stop script");
                        commandString = "\$GATEWAY_HOME/bin/stop_ns";
                    }
                    break;
                case 'Web':
                    envString = ". \$HOME/.profile; APACHE_HOME=$ServerHomeDirectory; export APACHE_HOME;";
                    if (actionString.toString().equalsIgnoreCase("start")) {
                        println(" Cooking Apache Server start script");
                        commandString = "\$APACHE_HOME/bin/startapa";
                    } else {
                        println(" Cooking Apache Server stop script");
                        commandString = "\$APACHE_HOME/bin/stopapa";
                    }
                    break;
                default:
                    throw new StepFailedException("Invalid server type: $serverType")
            }
            println(" " + envString);
            println(" " + commandString);
            writer.println("#!/usr/bin/sh");
            writer.println(envString);
            writer.println(commandString);
        } else {
            writer.println(myName + " Windows is not yet supported - please add code here TAG:STARTSTOP")
            //FILL IN REST OF SIEBEL ON WINDOWS THINGS. Don't have access to a windows Siebel server, so can't test it.
        }
    }
    scriptFile.setExecutable(true, false);


    //example commandHelper
    def ch = new CommandHelper(workDir);
    try {
        ch.runCommand("Applying Action on Server", [scriptFile.name, '', '']);
    } catch (ExitCodeException e) {
        throw new StepFailedException(e)
    }

    if (serverIsNotStarted) {
        if (isUnix) {
            println(" Making check script[")
            checkFile.withWriter { writer ->
                writer.println(". \$HOME/.profile; SIEBEL_HOME=" + ServerHomeDirectory + "; export SIEBEL_HOME; . \$SIEBEL_HOME/siebenv.sh;")
                println       ("outp=`\$SIEBEL_HOME/bin/srvrmgr /g $gwServer:$gwPort /e $SiebEnterprise /u $sbUser /p $sbPass /c \"list servers\"`")
                writer.println("outp=`\$SIEBEL_HOME/bin/srvrmgr /g $gwServer:$gwPort /e $SiebEnterprise /u $sbUser /p $sbPass /c \"list servers\"`")
                writer.println("echo \$outp")
                writer.println("mycount=`echo \$outp|grep -i " + siebelServer + "|grep -c Running`")
                writer.println("if [ \$mycount = 0 ]; then exit -1; else exit 0; fi")
            }
            checkFile.setExecutable(true, false);
        } else {
            writer.println(myName + " Windows is not yet supported - please add code here TAG:CHECK")
            //FILL IN REST OF SIEBEL ON WINDOWS THINGS. Don't have access to a windows Siebel server, so can't test it.
        }
    }

    ch.ignoreExitValue(true);
    def checkArgs = [checkFile.name, '', ''];
    while (serverIsNotStarted) {
        sleep(3000);
        int rc = ch.runCommand("$dateString: $myName: Checking to see if Siebel Server has started", checkArgs);
        println(" Checking server status. Exit code: " + rc)
        if (rc == 0) {
            serverIsNotStarted = false;
        }
    }

} catch (IOException e) {
    println ''
    println "ERROR: ${e.getMessage()}"
    System.exit(1)
} catch (StepFailedException e) {
    println ''
    println "ERROR: ${e.getMessage()}"
    System.exit(1)
} finally {
    println(" Cleaning up.")
    if (scriptFile.exists()) {
        if (!scriptFile.delete()) {
            println(" Could not delete script:[" + scriptFile.path + "] please delete manually")
        }
    }
    if (checkFile.exists()) {
        if (!checkFile.delete()) {
            println(" Could not delete check script:[" + checkFile.path + "] please delete manually")
        }
    }
    if (workDir.exists()) {
        if (!workDir.deleteDir()) {
            println(" Could not delete directory:[" + workDir.path + "] please delete manually")
        }
    }
}