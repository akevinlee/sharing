import com.serena.air.StepFailedException
import com.serena.air.StepPropertiesHelper
import com.serena.air.siebel.SiebelAPIHelper
import com.siebel.data.*
import com.urbancode.air.AirPluginTool

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = new StepPropertiesHelper(apTool.getStepProperties(), true)

String siebelServer        = props.notNull('SiebelServer')
int    siebelPort          = props.notNullInt('SiebelPort')
String sbUser              = props.notNull('SiebelUser')
String sbPass              = props.notNull('SiebelPass')
String siebelEnterprise    = props.notNull('SiebelEnterprise')

String action              = props.notNull('Action')
String flowSearchSpec      = props.notNull('FlowSearchSpec')
String exportDir           = props.notNull('DirPath')

try {
    SiebelAPIHelper sh = new SiebelAPIHelper()
    sh.login(
            siebelServer,
            siebelPort,
            siebelEnterprise,
            sbUser,
            sbPass)
    sh.actionWorkflow(action, flowSearchSpec, exportDir)
} catch (StepFailedException e) {
    println ''
    println "ERROR: ${e.getMessage()}"
    System.exit(1)
}