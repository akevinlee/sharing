package com.serena.air

import com.urbancode.air.CommandHelper
import org.apache.log4j.Logger

class ProcessHelper {
    private static final Logger logger = Logger.getLogger(ProcessHelper.class)

    public def run(ProcessBuilder processBuilder, def errMsgSrc){
        def res =  CommandHelper.waitForProcess(processBuilder.start())
        logger.debug("Process returned with code: ${res.exitCode}")
        logger.debug("StdOut= ${res.inputStream}")
        logger.debug("StdErr= ${res.errorStream}")
        commonResultChecks(res)

        //default error handling logic
        if(res.exitCode != 0) {
            switch (true) {
                case errMsgSrc instanceof String:
                    throw new StepFailedException(errMsgSrc as String)
                default:
                    throw new StepFailedException(errMsgSrc[res.exitCode])
            }
        }
    }

    public def run(ProcessBuilder processBuilder, Closure resultHandler){
        def res =  CommandHelper.waitForProcess(processBuilder.start())
        logger.debug("Process returned with code: ${res.exitCode}")
        logger.debug("StdOut= ${res.inputStream}")
        logger.debug("StdErr= ${res.errorStream}")
        commonResultChecks(res)
        return resultHandler(res)
    }

    public void commonResultChecks(def result){
        //does nothing. Overwrite it in your classes.
    }
}
