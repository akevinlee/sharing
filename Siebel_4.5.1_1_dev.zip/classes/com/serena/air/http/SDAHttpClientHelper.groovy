package com.serena.air.http

import com.urbancode.commons.util.httpclient.ApacheHttpClientFactory
import org.apache.http.impl.client.CloseableHttpClient;

class SDAHttpClientHelper {

    public static CloseableHttpClient getHttpClient(String username, String password) {
        String proxyHost = System.env['PROXY_HOST'] ? System.env['PROXY_HOST'] : null
        Integer proxyPort = System.env['PROXY_PORT'] ? Integer.valueOf((String) System.env['PROXY_PORT']) : null

        String sslEnabledProtocolsString = System.getenv()['SSL_ENABLED_PROTOCOLS']
        ArrayList<String> sslEnabledProtocolsList = null;
        if (null != sslEnabledProtocolsString) {
            sslEnabledProtocolsList = Arrays.asList(sslEnabledProtocolsString.split(","));
        }

        String agentKeyStorePath = System.env['com.serena.agent.keystore.path'] ? System.env['com.serena.agent.keystore.path'] : null
        String agentKeyStorePwd = System.env['com.serena.agent.keystore.pwd'] ? System.env['com.serena.agent.keystore.pwd'] : null
        String agentKeyStoreKeyPwd = System.env['com.serena.agent.keystore.key.pwd'] ? System.env['com.serena.agent.keystore.key.pwd'] : null

        ApacheHttpClientFactory factory = new ApacheHttpClientFactory(proxyHost, proxyPort);

        factory.setKeyStoreFilePath(agentKeyStorePath);
        factory.setKeyStorePassword(agentKeyStorePwd);
        factory.setKeyPassword(agentKeyStoreKeyPwd);

        factory.setAuthUsername(username);
        factory.setAuthPassword(password);

        factory.setSupportedSSLProtocols(sslEnabledProtocolsList);
        factory.setFollowRedirects(false);
        return factory.createHttpClient();
    }

    public static CloseableHttpClient getHttpClient() {
        return getHttpClient(null, null);
    }

}
