package com.serena.air.siebel

import com.serena.air.StepFailedException
import com.serena.air.Validation
import com.siebel.data.SiebelBusComp
import com.siebel.data.SiebelDataBean
import com.siebel.data.SiebelPropertySet
import com.siebel.data.SiebelService

class SiebelAPIHelper {
    SiebelDataBean m_dataBean = new SiebelDataBean();

    public void login(String server, int port, String enterprise, String user, String pass) {
        String connString = new String("siebel.TCPIP.None.None://$server:$port/$enterprise/EAIObjMgr_enu");
        println ("Connection string: $connString")
        m_dataBean.login(connString, user, pass, 'enu');
    }

    public void importWorkflow(String xmlPath) {
        SiebelService workflowService = m_dataBean.getService('Workflow Administration');

        SiebelPropertySet propertySetIN = creteSiebelProps([
            FileType: 'XML',
            FileName: xmlPath,
        ])
        SiebelPropertySet propertySetOUT = creteSiebelProps()


        workflowService.invokeMethod('Import', propertySetIN, propertySetOUT)

        println("Output: ")
        propertySetOUT.getPropertyNames().each {
            println("$it = ${propertySetOUT.getProperty(it)}")
        }
    }

    public void actionWorkflow(String action, String flowSearchSpec, String exportDir) {
        SiebelService workflowService = m_dataBean.getService('Workflow Admin Service');

        try{
            SiebelPropertySet propertySetIN
            switch (action){
                case 'Export':
                    propertySetIN = creteSiebelProps([
                            FlowSearchSpec: flowSearchSpec, // Process Name like \'MyTest\'
                            ExportDir     : exportDir,
                    ])
                    break;
                case 'Activate':
                case 'DeleteDeploy':
                    propertySetIN = creteSiebelProps([
                            FlowSearchSpec: flowSearchSpec
                    ])
                    break;
    //            case 'Deploy':
    //                propertySetIN = creteSiebelProps([
    //                        ImportDir: exportDir,
    ////                        Repository: exportDir, // not required
    ////                        ProjectName: exportDir,
    //                ])
    ////                m_FieldSetIN.setProperty("ImportDir",dProps['DirPath']);
    ////			m_FieldSetIN.setProperty("Repository",dProps['Repository']);
    ////			m_FieldSetIN.setProperty("ProjectName",dProps['ProjectName']);
    //                break;
                default:
                    throw new StepFailedException("Unsupported action: $action")
            }

            SiebelPropertySet propertySetOUT = creteSiebelProps()


            workflowService.invokeMethod(action, propertySetIN, propertySetOUT)

            println("Output: ")
            propertySetOUT.getPropertyNames().each {
                println("$it = ${propertySetOUT.getProperty(it)}")
            }
        }finally {
            workflowService.release()
        }
    }

    public void importBusinessService(String xmlPath) {
        SiebelService xmlFileReaderService = m_dataBean.getService('EAI XML Read from File');
        SiebelBusComp businessServiceComp = m_dataBean.getBusObject('Business Service').getBusComp('Business Service')

        try{
            SiebelPropertySet propertySetIN = creteSiebelProps([FileName: xmlPath])
            SiebelPropertySet propertySetOUT = creteSiebelProps()
            xmlFileReaderService.invokeMethod('ReadPropSet', propertySetIN, propertySetOUT)
            printOut('Properties of created Business Service: ', propertySetOUT)


            def fieldsToSet = [
                    'Display Name': propertySetOUT.getProperty('Display Name'),
                    'Name'        : propertySetOUT.getProperty('Name')
            ]
            setBusCompFields(businessServiceComp, propertySetOUT, fieldsToSet)
        } finally {
            businessServiceComp.release()
            xmlFileReaderService.release()
        }
    }

    public void importMessageTag(String xmlPath) {
        SiebelService xmlFileReaderService = m_dataBean.getService('EAI XML Read from File');
        SiebelService siebelAdapterService = m_dataBean.getService('EAI Siebel Adapter');

        try{
            SiebelPropertySet propertySetIN = creteSiebelProps([FileName: xmlPath])
            SiebelPropertySet propertySetMID = creteSiebelProps()
            SiebelPropertySet propertySetOUT = creteSiebelProps()

            xmlFileReaderService.invokeMethod('ReadEAIMsg', propertySetIN, propertySetMID)
            printOut('Properties of message tag that was read: ', propertySetMID)

            siebelAdapterService.invokeMethod('Upsert', propertySetMID, propertySetOUT);
            printOut('Properties of upserted message tag:', propertySetMID)
        } finally {
            xmlFileReaderService.release()
            siebelAdapterService.release()
        }
    }

    // ----- PRIVATE METHODS -----

    private String crSearchExpr(Map<String, String> props) {
        return props.collect { k, v -> "$k='$v'" }.join(' and ')
    }

    private boolean setBusCompFields(SiebelBusComp siebelBusComp, SiebelPropertySet fieldsToActivate, Map<String, String> propsToSet) {
        siebelBusComp.activateMultipleFields(fieldsToActivate);
        siebelBusComp.clearToQuery();
        String searchQuery = crSearchExpr(propsToSet)
        if (siebelBusComp.setSearchExpr(searchQuery)) {
            if (siebelBusComp.executeQuery(false)) {
                if (!siebelBusComp.firstRecord()) {
                    siebelBusComp.newRecord(false);
                }

                propsToSet.each { k, v ->
                    siebelBusComp.setFieldValue(k, v);
                }

                siebelBusComp.writeRecord();
            }
        }
        return true;
    }

    private void printOut(String msg, SiebelPropertySet out) {
        println(msg)
        out.getPropertyNames().each {
            println("$it = ${out.getProperty(it)}")
        }
    }

    private SiebelPropertySet creteSiebelProps() {
        return m_dataBean.newPropertySet()
    }

    private SiebelPropertySet creteSiebelProps(Map<String, String> data) {
        def res = m_dataBean.newPropertySet()
        data.each { k, v ->
            res.setProperty(k, v)
        }
        return res
    }
}
