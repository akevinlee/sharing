package com.serena.air.siebel

import com.serena.air.StepFailedException
import com.serena.air.Validation
import com.urbancode.air.CommandHelper

class SiebelCLIHelper {
    boolean isWindows
    private String pass
    private String user
    private String siebelHome

    SiebelCLIHelper(String siebelHome, String user, String pass, boolean isWindows) {
        this.siebelHome = siebelHome
        this.user = user
        this.pass = pass
        this.isWindows = isWindows
    }

    public void importExportRepo(String action, String dsn, String dbowner, String repoFilePath, String repository, String additionalParams){
        def ch = new CommandHelper();
        def args = []

        if(isWindows){
            File repoUtil = new File(siebelHome, 'bin/repimexp.exe')
            Validation.fileMustExist(repoUtil)
            args << repoUtil.canonicalPath
            args << '/C'
            args << dsn
            args << '/U'
            args <<  user
            args << '/P'
            args <<  pass
            args << '/D'
            args <<  dbowner
            switch (action){
                case 'Import':
                    args << '/A'
                    args << 'I'
                    break
                case 'Export':
                    args << '/A'
                    args << 'E'
                    break
                default:
                    throw new StepFailedException("Unknown action: $action")
            }
            args << '/F'
            args <<  repoFilePath
            if(repository){
                args << '/R'
                args <<  repository
            }

        } else {
            throw new StepFailedException("Unux is not supported for this step yet.")
        }

        additionalParams.split(' ').each{
            args << it.toString() // if it is not exactly String class -> RuntimeException later, when it will be cast to String[]
        }

        ch.runCommand("Importing Siebel repository", args)



    }

}
